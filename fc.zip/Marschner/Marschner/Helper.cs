﻿/*
  Copyright (C) 2010 Alexandru - Teodor Voicu
  Faculty of Automatic Control and Computer Science

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Library General Public
  License as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Library General Public License for more details.

  You should have received a copy of the GNU Library General Public
  License along with this library; if not, write to the Free
  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Marschner
{
	// Class implementing various functions mentioned in Marschner paper.
    class Helper
    {
        // Gaussian distribution - http://en.wikipedia.org/wiki/Normal_distribution
        public static double GaussianDistribution(double sigma, double x_mu)
        {
            return ((1 / (Math.Abs(sigma) * Math.Sqrt(2 * Math.PI))) *
                Math.Exp(-(x_mu * x_mu) / (2 * sigma * sigma)));
        }

        // Miller-Bravais indices - http://en.wikipedia.org/wiki/Miller_index
        public static double BravaisIndex(double theta, double eta)
        {
            double sinTheta = Math.Sin(theta);
            return (Math.Sqrt(eta * eta - sinTheta * sinTheta) / Math.Cos(theta));
        }

        // Fresnel equation parallel component - 
		//	http://en.wikipedia.org/wiki/Fresnel_equations
        public static double FresnelParallel(double n2, double angle)
        {
            double R = 1;
            double n1 = 1;
            double cos_gammaI = Math.Cos(angle);
            double a = ((n1 / n2) * Math.Sin(angle));
            double b = a * a;

            if (b > 1)
                return R;

            double cos_gammaT = Math.Sqrt(1 - b);

            R = (n2 * cos_gammaI - n1 * cos_gammaT) / 
				(n2 * cos_gammaI + n1 * cos_gammaT);

            return Math.Min(1, R * R);
        }

		// Fresnel equation perpendicular component - 
		//	http://en.wikipedia.org/wiki/Fresnel_equations
        public static double FresnelPerpendicular(double n2, double angle)
        {
            double R = 1;
            double n1 = 1;
            double cos_gammaI = Math.Cos(angle);
            double a = ((n1 / n2) * Math.Sin(angle));
            double b = a * a;

            if (b > 1)
                return R;

            double cos_gammaT = Math.Sqrt(1 - b);

            R = (n1 * cos_gammaI - n2 * cos_gammaT) / 
				(n1 * cos_gammaI + n2 * cos_gammaT);

            return Math.Min(1, R * R);
        }

		// Fresnel equation - http://en.wikipedia.org/wiki/Fresnel_equations
        public static double Fresnel(double etaPerpendicular, double etaParallel, 
			double angle)
        {
            return 0.5f * (FresnelPerpendicular(etaPerpendicular, angle) + 
				FresnelParallel(etaParallel, angle));
        }

		// Clamp function for double values - common shader function
        public static double Clamp (double x, double min, double max)
        {
            if (x < min)
                return min;
            if (x > max)
                return max;
            return x;
        }

		// Saturate function - common shader function
        public static double Saturate(double x)
        {
            return Clamp(x, 0, 1);
        }

		// Smoothstep function - common shader function
        public static double Smoothstep(double edge0, double edge1, double x)
        {
            // Scale, bias and saturate x to 0..1 range
            double t = Saturate((x - edge0) / (edge1 - edge0));
            // Evaluate polynomial
            return t * t * (3 - 2 * t);
        }
    }

	// Class that solves equations from linear to cubic
    class Equation
    {
        // Solve a * x + b = 0 - linear equation
        public static double4 LinearSolver(double a, double b)
        {
            double4 roots = new double4();

            if (Math.Abs(a) > Form1.EPS)
            {
                roots[0] = -b / a;
                roots[3] = 1;
            }

            return roots;
        }

        // Solve a * x ^ 2 + b * x + c = 0 - quadratic equation
        public static double4 QuadraticSolver(double a, double b, double c)
        {
            double4 roots;

            if (Math.Abs(a) < Form1.EPS)
                return LinearSolver(b, c);
            else
            {
                roots = new double4();

                double D = b * b - 4 * a * c;

                if (Math.Abs(D) < Form1.EPS)
                {
                    roots[0] = -b / (2 * a);
                    roots[1] = -b / (2 * a);
                    roots[3] = 2;
                }
                else if (D > 0)
                {
                    double delta = Math.Sqrt(D);
                    roots[0] = (-b + delta) / (2 * a);
                    roots[1] = (-b - delta) / (2 * a);
                    roots[3] = 2;
                }
            }

            return roots;
        }

        // Solve x ^ 3 + A * x ^ 2 + B * x + C = 0 - normalized cubic equation
		//  http://en.wikipedia.org/wiki/Cubic_function
        public static double4 NormalizedCubicSolver(double A, double B, double C)
        {
            double4 roots;

            if (Math.Abs(C) < Form1.EPS)	//	x = 0 solution
            {
                roots = QuadraticSolver(1, A, B);
				roots[(int)roots.W] = 0;
				roots.W++;
            }
            else
            {
                roots = new double4();

                double Q = (3 * B - A * A) / 9;
                double R = (9 * A * B - 27 * C - 2 * A * A * A) / 54;
                double D = Q * Q * Q + R * R;

                if (D > 0)	// 1 root
                {
                    double sqrtD = Math.Sqrt(D);
                    double s = Math.Sign(R + sqrtD) * 
						Math.Pow(Math.Abs(R + sqrtD), 1.0f / 3.0f);
                    double t = Math.Sign(R - sqrtD) * 
						Math.Pow(Math.Abs(R - sqrtD), 1.0f / 3.0f);

                    roots[0] = (-A / 3 + (s + t));
                    roots[3] = 1;
                }
                else	// 3 roots
                {
                    double theta = Math.Acos(R / Math.Sqrt(-(Q * Q * Q)));
                    double sqrtQ = Math.Sqrt(-Q);
                    roots[0] = (2 * sqrtQ * Math.Cos(theta / 3) - A / 3);
                    roots[1] = (2 * sqrtQ * 
						Math.Cos((theta + 2 * Math.PI) / 3) - A / 3);
                    roots[2] = (2 * sqrtQ * 
						Math.Cos((theta + 4 * Math.PI) / 3) - A / 3);
                    roots[3] = 3;
                }
            }

            return roots;
        }

		// Test if the roots for a cubic equations are correct
        public static void TestRoots(double a, double b, double c, double d, 
			double4 roots)
        {
            double val;

            for (int i = 0; i < roots.W; i++)
                if ((val = Math.Abs((((a * roots[i] + b) * 
					roots[i]) + c) * roots[i] + d)) > Form1.EPS)
						Console.WriteLine("Error " + i + " A=" + a + " B=" +
							b + " C=" + c + " D=" + d + " " + (val - Form1.EPS));
        }

        // Solve a * x ^ 3 + b * x ^ 2 + c * x  + d = 0 - cubic equation
		//	http://en.wikipedia.org/wiki/Cubic_function
        public static double4 CubicSolver(double a, double b, double c, double d)
        {
            double4 roots;

            if (Math.Abs(a) < Form1.EPS)
                roots = QuadraticSolver(b, c, d);
            else
                roots = NormalizedCubicSolver(b / a, c / a, d / a);

            TestRoots(a, b, c, d, roots);

            return roots;
        }

        // Solve o(p,y) - phi = 0
        public static double4 Roots(double p, double etaPerpendicular, double phi)
        {
            double c = Math.Asin(1 / etaPerpendicular);

            return CubicSolver(-8 * (p * c / (Math.PI * Math.PI * Math.PI)), 0, 
				(6 * p * c / Math.PI - 2), p * Math.PI - phi);
        }

        // computes the angle polygon
        public static double AnglePolynomial(double p, double etaPerpendicular, 
			double h)
        {
            double gammaI = Math.Asin(h);
            double c = Math.Asin(1 / etaPerpendicular);
            return (6 * p * c / Math.PI - 2) * gammaI - 
				8 * (p * c / (Math.PI * Math.PI * Math.PI)) 
                * gammaI * gammaI * gammaI + p * Math.PI;
        }

        // Computes the derivative of the polynomial relative to h.
        public static double InverseFirstDerivate(double p, 
			double etaPerpendicular, double h)
        {
            double gammaI = Math.Asin(h);
            double c = Math.Asin( 1 / etaPerpendicular );
            double dGamma = (6 * p * c / Math.PI - 2) - 
				3 * 8 * (p * c / (Math.PI * Math.PI * Math.PI)) * gammaI * gammaI;

            return Math.Sqrt(1 - h * h) / dGamma;
        }

        // Computes the second derivative of the polynomial relative to h.
        public static double InverseSecondDerivateApproximation(double p, 
			double etaPerpendicular, double h)
        {
            double gammaI = Math.Asin(h);
            double c = Math.Asin(1 / etaPerpendicular);
            double dGamma = -2 * 3 * 8 * 
				(p * c / (Math.PI * Math.PI * Math.PI)) * gammaI;

            double denom = Math.Max(dGamma * h, Form1.EPS);
            return Math.Pow(1 - h * h, 3.0 / 2.0) / denom;
        }

        // computes the second derivative of the polynomial relative to h.
        public static double InverseSecondDerivateFull(double p, 
			double etaPerpendicular, double h)
        {
            double gammaI = Math.Asin(h);
            double c = Math.Asin(1 / etaPerpendicular);
            
			// h' = (f'g - fg') / g^2
            double f = (6 * p * c / Math.PI - 2) - 3 * 8 * 
				(p * c / (Math.PI * Math.PI * Math.PI)) * gammaI * gammaI;
            double df = -2 * 3 * 8 * (p * c / (Math.PI * Math.PI * Math.PI)) * gammaI;
            double g = Math.Sqrt(1 - h * h);
            double dg = h / Math.Max( g , Form1.EPS);

            return (g * g) / (Math.Max( df * g - f * dg , Form1.EPS ));
        }
    }
}
