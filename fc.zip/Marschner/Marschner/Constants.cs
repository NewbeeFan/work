﻿/*
  Copyright (C) 2010 Alexandru - Teodor Voicu
  Faculty of Automatic Control and Computer Science

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Library General Public
  License as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Library General Public License for more details.

  You should have received a copy of the GNU Library General Public
  License along with this library; if not, write to the Free
  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Marschner
{
/*
  Surface properties
    aR longitudinal shift: R lobe -10 to -5
    aTT longitudinal shift: TT lobe -aR/2
    aTRT longitudinal shift: TRT lobe -3aR/2
 
    bR longitudinal width (stdev.): R lobe 5 to 10
    bTT longitudinal width (stdev.): TT lobe bR/2
    bTRT longitudinal width (stdev.): TRT lobe 2bR
  
   Fiber properties
	eta: 1.55
	absorption: 0.2 to inf
	eccentricity: 0.85 to 1
 
   Glints
    kG glint scale factor: 0.5 to 5
    wc azimuthal width of caustic: 10 to 25
    Dh0 fade range for caustic merge: 0.2 to 0.4
    DhM caustic intensity limit: 0.5
*/
    class Constants
    {
        public const double aR = -10;
        public const double aTT = - aR / 2;
        public const double aTRT = - 3 * aR / 2;

        public const double bR = 5;
        public const double bTT = bR / 2;
        public const double bTRT = 2 * bR;

        public const double eta = 1.55;
        public const double absorption = 0.2;
        public const double eccentricity = 0.85;

        public const double kG = 0.5;
        public const double wc = 10;
        public const double Dh0 = 0.2;
        public const double DhM = 0.5;
    }
}
