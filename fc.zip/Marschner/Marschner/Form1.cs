﻿/*
  Copyright (C) 2010 Alexandru - Teodor Voicu
  Faculty of Automatic Control and Computer Science

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Library General Public
  License as published by the Free Software Foundation; either
  version 2 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Library General Public License for more details.

  You should have received a copy of the GNU Library General Public
  License along with this library; if not, write to the Free
  Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Marschner
{
    public partial class Form1 : Form
    {
        const int WIDTH = 256, HEIGHT = 256;
        public const double EPS = 0.00001f;

        public Form1()
        {
            InitializeComponent();
            M();
            N();
            //TestCubicSolver();
            //TestFresnel();
        }

		// Compute the M factor for each channel
        private double Compute_M(Bitmap bmp, double a, double b, Color Channel)
        {
            double max = 0;

            double [,] gauss_matrix = new double[WIDTH, HEIGHT];

            // Find max
            for (int x = 0; x < WIDTH; x++)
                for (int y = 0; y < HEIGHT; y++)
                {
                    double sin_thI = -1.0f + (x * 2.0f) / WIDTH;
                    double sin_thR = -1.0f + (y * 2.0f) / HEIGHT;
                    double thI = (180 * Math.Asin(sin_thI) / Math.PI);
                    double thR = (180 * Math.Asin(sin_thR) / Math.PI);
                    double thH = (thR + thI) / 2;
                    double thH_a = thH - a;

                    Color col = bmp.GetPixel(x, y);

                    double gauss = Helper.GaussianDistribution(b, thH_a);
                    gauss_matrix[x, y] = gauss;

                    if (255 * gauss > max)
                        max = 255 * gauss;
                }

            // Normalize
            for (int x = 0; x < WIDTH; x++)
                for (int y = 0; y < HEIGHT; y++)
                {
                    Color col = bmp.GetPixel(x, y);

                    double gauss = gauss_matrix[x, y];

                    bmp.SetPixel(x, y, Color.FromArgb(
                        (int)(Channel.R * Channel.R * gauss / max) + 
							(1 - Channel.R / 255) * col.R,
                        (int)(Channel.G * Channel.G * gauss / max) + 
							(1 - Channel.G / 255) * col.G,
                        (int)(Channel.B * Channel.B * gauss / max) + 
							(1 - Channel.B / 255) * col.B));
                }

            return max;
        }
        
		// The M lookup texture
        private void M()
        {
            Bitmap bmp = new Bitmap(WIDTH, HEIGHT);

            Console.WriteLine( Compute_M(bmp, Constants.aR, 
				Constants.bR, Color.FromArgb(255, 0, 0)) / 255.0 );
            Console.WriteLine( Compute_M(bmp, Constants.aTT, 
				Constants.bTT, Color.FromArgb(0,255,0)) / 255.0f );
            Console.WriteLine( Compute_M(bmp, Constants.aTRT, 
				Constants.bTRT, Color.FromArgb(0, 0, 255)) / 255.0 );
            
            pictureBox1.Image = bmp;
            bmp.Save("M.bmp");
        }

        private double T(double absorption, double gammaT)
        {
			// l = ls / cos qt = 2r cos h0t / cos qt
            double l = 1 + Math.Cos(2 * gammaT);
            return Math.Exp(-2 * absorption * l);
        }

        private double A(double absorption, int p, double h, double refraction, 
			double etaPerpendicular, double etaParallel)
        {
            double gammaI = Math.Asin(h);

            // A(0; h) = F(h0; h00; gi)
            if (p == 0)
                return Helper.Fresnel(etaPerpendicular, etaParallel, gammaI);

            // A(p; h) = ( (1 - F(h0; h00; gi) ) ^ 2 ) * 
			//	( F(1 / h0; 1 / h00; gi) ^ (p - 1) ) * ( T(s0a; h) ^ p )
            double gammaT = Math.Asin(h / etaPerpendicular);	// h0 sin gt = h

            double fresnel = Helper.Fresnel(etaPerpendicular, etaParallel, gammaI);
            double invFrenel = Helper.Fresnel(1 / etaPerpendicular, 
				1 / etaParallel, gammaT);
            double t = T(absorption, gammaT);

            //if (roots > 1 && fresnel * invFrenel != 1)
            //    Console.WriteLine( " f " + fresnel + " i " + invFrenel );

            return (1 - fresnel) * (1 - fresnel) * Math.Pow(invFrenel, p - 1) 
				* Math.Pow(t, p);
        }

		// The NP function from Marschner
        private double NP(int p, double phi, double thD)
        {
            double refraction = Constants.eta;
            double absorption = Constants.absorption;

            double etaPerpendicular = Helper.BravaisIndex(thD, refraction);
            double etaParallel = (refraction * refraction) / etaPerpendicular;

            double4 roots = Equation.Roots(p, etaPerpendicular, phi);
            double result = 0;

            for (int index = 0; index < roots.W; index++ )
            {
                double gammaI = roots[index];

                //if (Math.Abs(gammaI) <= Math.PI/2)
                {
                    double h = Math.Sin(gammaI);
                    double finalAbsorption = A(absorption, p, h, refraction, 
						etaPerpendicular, etaParallel);
                    double inverseDerivateAngle = 
						Equation.InverseFirstDerivate(p, etaPerpendicular, h);

                    result += finalAbsorption * 2 * Math.Abs(inverseDerivateAngle); //0.5 here

                    //if (roots.W > 1 && result != 0)
                    //    Console.WriteLine(index + " g " + gammaI + " f " + finalAbsorption + " r " + result);
                }
            }

            return Math.Min(1, result);
        }

		// The NTRT function from Marschner
        private double NTRT(double cos_phiD, double cos_thD)
        {
            double phi = Math.Acos(cos_phiD);
            double thD = Math.Acos(cos_thD);
            phi = cos_phiD;
            thD = cos_thD;

            double causticLimit = Constants.DhM;
            double causticWidth = Constants.wc * Math.PI / 180;
            double glintScale = Constants.kG;
            double causticFade = Constants.Dh0;

            double refraction = Constants.eta;
            double absorption = Constants.absorption;

            double etaPerpendicular = Helper.BravaisIndex(thD, refraction);
            double etaParallel = (refraction * refraction) / etaPerpendicular;

            double dH, t, hc, gammaC;

            if (etaPerpendicular < 2)
            {
                double c = Math.Asin(1 / etaPerpendicular);
                gammaC = Math.Sqrt((6 * 2 * c / Math.PI - 2) / 
					(3 * 8 * (2 * c / (Math.PI * Math.PI * Math.PI))));
                hc = Math.Abs(Math.Sin(gammaC));

                double inverseDerivateAngle = 
					Equation.InverseSecondDerivateFull(2, etaPerpendicular, hc);
                dH = Math.Min(causticLimit, 
					2 * Math.Sqrt(2 * causticWidth * inverseDerivateAngle));
                t = 1;
            }
            else
            {
                gammaC = 0;
                hc = 0;
                dH = causticLimit;
                t = 1 - Helper.Smoothstep(2, 2 + causticFade, etaPerpendicular);
            }
            
            gammaC = Equation.AnglePolynomial(2, etaPerpendicular, hc);
            double result = NP(2, cos_phiD, cos_thD);
            double finalAbsorption = 
				A(absorption, 2, hc, refraction, etaPerpendicular, etaParallel);

            result = result * (1 - t * Helper.GaussianDistribution(causticWidth, phi - gammaC) /
                Helper.GaussianDistribution(causticWidth, 0));
            result = result * (1 - t * Helper.GaussianDistribution(causticWidth, phi + gammaC) /
                Helper.GaussianDistribution(causticWidth, 0));

            result = result + t * glintScale * finalAbsorption * dH *
                (Helper.GaussianDistribution(causticWidth, phi - gammaC) +
                    Helper.GaussianDistribution(causticWidth, phi + gammaC));

            return Math.Min(1, result);
        }

		// The NP function for P = 0
        private double NP_Simple(double phi, double thD)
        {
            double refraction = Constants.eta;

            double etaPerpendicular = Helper.BravaisIndex(thD, refraction);
            double etaParallel = (refraction * refraction) / etaPerpendicular;
            double gammaI = -phi / 2;

            double h = Math.Sin(gammaI);

            double result = (Math.Sqrt(1 - h * h));

            result *= Helper.Fresnel(etaPerpendicular, etaParallel, gammaI);

            return Math.Min(1, result);
        }

        private void N()
        {
            Bitmap bmp = new Bitmap(WIDTH, HEIGHT);

            // NR
            for (int x = 0; x < WIDTH; x++)
                for (int y = 0; y < HEIGHT; y++)
                {
                    double cos_phiD = -1.0 + (x * 2.0) / WIDTH;
                    double cos_thD = -1.0 + (y * 2.0) / HEIGHT;
                    double phiD = Math.Acos(cos_phiD);
                    double thD = Math.Acos(cos_thD);
                    
                    bmp.SetPixel(x, y, Color.FromArgb(
                        //(int)(255 * NP_Simple(phiD, thD)),
						(int)(255 * NP(0,phiD, thD)),
						(int)(255 * NP(1, phiD, thD)),
                        (int)(255 * NP(2, phiD, thD))));
						//(int)(255 * NTRT(phiD, thD)), 0, 0));
                }

            pictureBox2.Image = bmp;
            bmp.Save("N.bmp");
        }

		// Test the cubic solver implementation
        private void TestCubicSolver()
        {
            Random r = new Random((int)DateTime.Now.Ticks);

            for (int i = 0; i < 100000; i++)
            {
                double a = r.NextDouble() * 200.0f - 100.0f;
                double b = r.NextDouble() * 200.0f - 100.0f;
                double c = r.NextDouble() * 200.0f - 100.0f;
                double d = r.NextDouble() * 200.0f - 100.0f;

                double4 roots = Equation.CubicSolver(a, b, c, d);
                double val;

                for (int j = 0; j < roots.W; j++)
                    if ( (val = Math.Abs((((a * roots[j] + b) * roots[j]) + c) 
						* roots[j] + d)) > EPS)
                        Console.WriteLine("Error " + i + " A=" + a + " B=" +
                            b + " C=" + c + " D=" + d + " " + (val - EPS));
            }
        }

        // Tested with this - http://demonstrations.wolfram.com/FresnelEquations/
        private void TestFresnel()
        {
            Bitmap bmp = new Bitmap(WIDTH, HEIGHT);

            for (int x = 0; x < WIDTH; x++)
                for (int y = 0; y < HEIGHT; y++)
                    bmp.SetPixel(x, y, Color.FromArgb(0, 0, 0));

            for (int x = 0; x < WIDTH; x++)
            {
                double angle = ( (x * 90) / WIDTH ) * Math.PI / 180;

                int y = HEIGHT - 1 - (int)((HEIGHT - 1) * Helper.FresnelPerpendicular(1.5, angle));
                bmp.SetPixel(x, y, Color.FromArgb(
                    255, 0, 0));

                y = HEIGHT - 1 - (int)((HEIGHT - 1) * Helper.FresnelParallel(1.5, angle));
                bmp.SetPixel(x, y, Color.FromArgb(
                    0, 255, 0));
            }

            bmp.Save("Fresnel.bmp");            
        }
    }
}
