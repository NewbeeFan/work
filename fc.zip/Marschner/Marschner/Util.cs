﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Marschner
{
    public class double3
    {
        public double X, Y, Z;

        public double3()
        {
            X = Y = Z = 0;
        }

        public double3(double X, double Y, double Z)
        {
            this.X = X;
            this.Y = Y;
            this.Z = Z;
        }

        public double this[int index]
        {
            get
            {
                switch (index)
                {
                    case 0: { return X; }
                    case 1: { return Y; }
                    case 2: default: { return Z; }
                }
            }
            set
            {
                switch (index)
                {
                    case 0: { X = value; break; }
                    case 1: { Y = value; break; }
                    case 2: default: { Z = value; break; }
                }
            }
        }
    }

    public class double4
    {
        public double X, Y, Z, W;

        public double4()
        {
            X = Y = Z = W = 0;
        }

        public double4(double X, double Y, double Z, double W)
        {
            this.X = X;
            this.Y = Y;
            this.Z = Z;
            this.W = W;
        }

        public double this[int index]
        {
            get
            {
                switch (index)
                {
                    case 0: { return X; }
                    case 1: { return Y; }
                    case 2: { return Z; }
                    case 3: default: { return W; }
                }
            }
            set
            {
                switch (index)
                {
                    case 0: { X = value; break; }
                    case 1: { Y = value; break; }
                    case 2: { Z = value; break; }
                    case 3: default: { W = value; break; }
                }
            }
        }
    }
}
